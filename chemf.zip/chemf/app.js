document.querySelector("#info").addEventListener("click", function() {
    location.href = "info.html";
});